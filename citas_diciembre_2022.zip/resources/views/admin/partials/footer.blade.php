<div class="footer-wrapper">
    <div class="footer-section f-section-1">
    </div>
    <div class="footer-section f-section-2">
        <p class="text-right"><span class="text-primary">{{ $setting->name }}</span> Todos los derechos reservados {{ date("Y") }}.</p>
    </div>
</div>